import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import youtube from '../img/youtube.png'; // Import your YouTube icon here
const DashboardContent = () => {
  const [activeTab, setActiveTab] = useState('Monthly');
  
  const newsItems = [
    {
      id: 1,
      title: 'Advisory on Case Insensitivity in IRN Generation',
      date: 'Apr 4th, 2025',
      category: 'E-Invoice'
    },
    {
      id: 2,
      title: 'Advisory for Biometric-Based Aadhaar Authentication and Document Verification for GST Registration Applicants of Assam',
      date: 'Apr 4th, 2025',
      category: 'Registration'
    },
    {
      id: 3,
      title: 'Gross and Net GST revenue collections for the month of Mar, 2025',
      date: 'Apr 4th, 2025',
      category: 'OTHER'
    }
  ];

  const helpTopics = [
    'How do I register with GST?',
    'How do I apply for refund?',
    'How do I file returns?',
    'How can I use Returns Offline Tool?',
    'How do I file an appeal?',
    'How do I file intimation about voluntary payment?'
  ];

  const dueDateRows = [
    [
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' }
    ],
    [
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' }
    ],
    [
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' },
      { form: 'GSTR-3B (Mar, 2025)', date: 'Apr 20th, 2025' }
    ]
  ];

  const mediaItems = [
    {
      id: 1,
      title: 'Know more about Map-based Geocoding in the Registration process. Watch the video.',
      date: 'Mar 1st, 2024'
    },
    {
      id: 2,
      title: 'How to validate Digital Signature affixed to the downloaded document from the GST Portal?',
      date: 'Mar 1st, 2024'
    },
    {
      id: 3,
      title: 'How to utilise Cash/ITC for payment of demand? Watch video...',
      date: 'Mar 1st, 2024'
    }
  ];

  return (
    <div className="bg-gray-100 p-2 sm:p-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Row 1 - News and Help Topics */}
        <div className="flex flex-col">
          {/* News and Updates Section */}
          <div className="relative pt-4 mb-4">
            <div className="flex justify-between items-center px-2 sm:px-4 absolute -top-1 left-0 right-0">
              <h2 className="text-sm sm:text-base font-medium text-gray-800 bg-gray-100 px-2">News and Updates</h2>
              <a href="#" className="text-blue-600 text-xs hover:underline bg-gray-100 px-2">View all</a>
            </div>
            <div className="bg-white rounded-md shadow border border-gray-200 h-auto sm:h-64">
              {newsItems.map((item, index) => (
                <div 
                  key={item.id} 
                  className={`p-3 sm:p-4 ${index < newsItems.length - 1 ? 'border-b' : ''} ${index === 1 ? 'bg-blue-50' : ''}`}
                >
                  <h3 className="font-medium text-xs sm:text-sm text-blue-800 mb-1">{item.title}</h3>
                  <div className="flex flex-wrap sm:flex-nowrap justify-between items-center text-xs">
                    <span className="text-gray-500">{item.date}</span>
                    <span className="bg-gray-100 px-2 py-0.5 rounded text-gray-600 mt-1 sm:mt-0">{item.category}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Popular help topics */}
        <div className="flex flex-col">
          <div className="relative pt-4 mb-4">
            <div className="absolute -top-1 left-0 right-0 px-2 sm:px-4">
              <h2 className="text-sm sm:text-base font-medium text-gray-800 bg-gray-100 px-2 inline-block">Popular help topics</h2>
            </div>
            <div className="bg-white rounded-md shadow border border-gray-200 h-auto sm:h-64">
              {helpTopics.map((topic, index) => (
                <div key={index} className="border-b last:border-b-0">
                  <a href="#" className="flex justify-between items-center px-3 sm:px-4 py-2 sm:py-2.5 hover:bg-gray-50">
                    <span className="text-xs sm:text-sm text-gray-800">{topic}</span>
                    <ChevronRight className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400 flex-shrink-0 ml-1" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Row 2 - Due Dates and Media */}
        <div className="flex flex-col">
          {/* Upcoming Due Dates */}
          <div className="relative pt-4 mb-4">
            <div className="flex justify-between items-center px-2 sm:px-4 absolute -top-1 left-0 right-0">
              <div className="flex items-center">
                <svg className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="3" y="6" width="18" height="15" rx="2" stroke="#2563EB" strokeWidth="2" />
                  <path d="M3 10H21" stroke="#2563EB" strokeWidth="2" />
                  <path d="M8 3V7" stroke="#2563EB" strokeWidth="2" strokeLinecap="round" />
                  <path d="M16 3V7" stroke="#2563EB" strokeWidth="2" strokeLinecap="round" />
                </svg>
                <h2 className="text-sm sm:text-base font-medium text-gray-800 bg-gray-100 px-2">Frame 167</h2>
              </div>
              <a href="#" className="text-blue-600 text-xs hover:underline bg-gray-100 px-2">Download PDF</a>
            </div>
            <div className="bg-white rounded-md shadow border border-gray-200">
              {/* Tabs - Scrollable on mobile */}
              <div className="flex overflow-x-auto border-b">
                <button 
                  className={`px-3 sm:px-6 py-1.5 text-xs sm:text-sm font-medium whitespace-nowrap ${activeTab === 'Monthly' ? 'bg-blue-100 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600'}`}
                  onClick={() => setActiveTab('Monthly')}
                >
                  Monthly
                </button>
                <button 
                  className={`px-3 sm:px-6 py-1.5 text-xs sm:text-sm font-medium whitespace-nowrap ${activeTab === 'Quarterly' ? 'bg-blue-100 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600'}`}
                  onClick={() => setActiveTab('Quarterly')}
                >
                  Quarterly
                </button>
                <button 
                  className={`px-3 sm:px-6 py-1.5 text-xs sm:text-sm font-medium whitespace-nowrap ${activeTab === 'Other' ? 'bg-blue-100 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600'}`}
                  onClick={() => setActiveTab('Other')}
                >
                  Other Due Dates
                </button>
              </div>
              
              {/* Due date grid - Responsive with different layouts */}
              <div className="overflow-x-auto">
                <div className="min-w-full">
                  {dueDateRows.map((row, rowIndex) => (
                    <div key={rowIndex} className={`grid grid-cols-2 sm:grid-cols-4 ${rowIndex < dueDateRows.length - 1 ? 'border-b' : ''}`}>
                      {row.map((item, colIndex) => (
                        <div key={colIndex} className={`p-2 text-center ${colIndex < row.length - 1 && (colIndex % 2 !== 1 || window.innerWidth >= 640) ? 'border-r' : ''}`}>
                          <div className="text-xs font-medium mb-1">{item.form}</div>
                          <div className="flex justify-center items-center">
                            <span className="text-xs text-gray-600">{item.date}</span>
                            <div className="ml-1 w-2 h-2 rounded-full bg-gray-300"></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Help desk info */}
              <div className="p-2 sm:p-3 bg-gray-50 border-t">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="mb-2 sm:mb-0">
                    <div className="text-xs text-gray-500">Help Desk Number:</div>
                    <div className="text-xs sm:text-sm font-medium">1800-103-4786</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Log/Track Your Issues here</div>
                    <div className="text-xs">
                      <a href="#" className="flex items-center text-gray-600">
                        Grievance Redressal
                        <span className="ml-1 inline-flex items-center justify-center w-4 h-4 border border-gray-500 rounded-sm text-xs">ⓘ</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* GST Media */}
<div className="flex flex-col">
  <div className="relative pt-4 mb-4">
    <div className="flex justify-between items-center px-2 sm:px-4 absolute -top-1 left-0 right-0">
      <h2 className="text-sm sm:text-base font-medium text-gray-800 bg-gray-100 px-2">GST Media</h2>
      <a href="#" className="text-blue-600 text-xs hover:underline bg-gray-100 px-2 flex items-center">
        View all
        <span className="ml-1 inline-flex items-center justify-center w-4 h-4 border border-blue-600 rounded-sm text-xs">ⓘ</span>
      </a>
    </div>
    <div className="bg-white rounded-md shadow border border-gray-200 h-auto sm:h-64">
      {mediaItems.map((item, index) => (
        <div key={index} className={`p-2 sm:p-3 flex items-start ${index < mediaItems.length - 1 ? 'border-b' : ''} ${index % 2 === 1 ? 'bg-blue-50' : ''}`}>
          <div className="w-12 h-10 sm:w-16 sm:h-12 bg-gray-200 rounded relative flex-shrink-0 mr-2 sm:mr-3">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-red-600 flex items-center justify-center">
                <img 
                  src={youtube}
                  alt="Play button"
                  className="w-2 h-2 sm:w-3 sm:h-3" 
                />
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-xs font-medium text-blue-800 mb-1">{item.title}</h3>
            <div className="text-xs text-gray-500">Uploaded On: {item.date}</div>
          </div>
        </div>
      ))}
    </div>
  </div>
</div>
      </div>
    </div>
  );
};
export default DashboardContent;
