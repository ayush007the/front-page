import { useState } from 'react';

export default function RegistrationForm() {
  const [formData, setFormData] = useState({
    registrationType: 'TRN',
    userType: '',
    stateUT: '',
    district: '',
    legalName: '',
    panNumber: '',
    email: '',
    mobile: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleRadioChange = (e) => {
    setFormData({
      ...formData,
      registrationType: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Submit logic here
  };

  return (
    <div className="bg-gray-100 min-h-screen py-6 text-left">
      <div className="max-w-3xl mx-auto">
        {/* Navigation */}
        <div className="flex justify-between items-center mb-4 px-4">
          <div className="text-blue-600 text-sm">
            <span>Home</span>
            <span className="mx-1">&gt;</span>
            <span>Registration</span>
          </div>
          <div className="flex items-center">
            <span className="text-sm mr-1">🌐</span>
            <span className="text-sm text-gray-800">English</span>
          </div>
        </div>

        {/* Main content */}
        <div className="bg-white rounded-md shadow-sm p-6">
          {/* Steps indicator */}
          <div className="flex justify-center items-center mb-8">
            <div className="relative flex items-center">
              <div className="rounded-full bg-yellow-400 text-white w-8 h-8 flex items-center justify-center z-10">
                1
              </div>
              <span className="text-xs text-center absolute w-24 mt-16 text-gray-800">User Credentials</span>
              <div className="w-24 h-0.5 bg-gray-300"></div>
              <div className="rounded-full bg-gray-500 text-white w-8 h-8 flex items-center justify-center z-10">
                2
              </div>
              <span className="text-xs text-center absolute w-24 mt-16 ml-24 text-gray-800">OTP Verification</span>
            </div>
          </div>

          <h1 className="text-2xl font-medium mb-6 border-b pb-4 text-gray-800">New Registration</h1>
          <p className="mb-4 text-right text-sm text-gray-800">
            <span className="text-red-500">*</span> indicates mandatory fields
          </p>

          <form onSubmit={handleSubmit}>
            {/* Registration Type */}
            <div className="mb-6 flex items-center space-x-8">
              <label className="flex items-center text-gray-800">
                <input
                  type="radio"
                  name="registrationType"
                  value="TRN"
                  checked={formData.registrationType === 'TRN'}
                  onChange={handleRadioChange}
                  className="mr-2 text-blue-600"
                />
                <span>Temporary Reference Number (TRN)</span>
              </label>
              <label className="flex items-center text-gray-800">
                <input
                  type="radio"
                  name="registrationType"
                  value="NEW"
                  checked={formData.registrationType === 'NEW'}
                  onChange={handleRadioChange}
                  className="mr-2 text-blue-600"
                />
                <span>New Registration</span>
              </label>
            </div>

            {/* User Type */}
            <div className="mb-6">
              <label className="block mb-2 text-sm font-medium text-gray-800">
                I am a <span className="text-red-500">*</span>
              </label>
              <select
                name="userType"
                value={formData.userType}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md text-gray-800"
                required
              >
                <option value="">Select</option>
                <option value="individual">Individual</option>
                <option value="business">Business</option>
                <option value="professional">Professional</option>
              </select>
            </div>

            {/* State / UT */}
            <div className="mb-6">
              <label className="block mb-2 text-sm font-medium text-gray-800">
                State / UT <span className="text-red-500">*</span>
              </label>
              <select
                name="stateUT"
                value={formData.stateUT}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md text-gray-800"
                required
              >
                <option value="">Select</option>
                <option value="delhi">Delhi</option>
                <option value="maharashtra">Maharashtra</option>
                <option value="karnataka">Karnataka</option>
                <option value="tamilnadu">Tamil Nadu</option>
              </select>
            </div>

            {/* District */}
            <div className="mb-6">
              <label className="block mb-2 text-sm font-medium text-gray-800">
                District <span className="text-red-500">*</span>
              </label>
              <select
                name="district"
                value={formData.district}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-300 rounded-md text-gray-800"
                required
              >
                <option value="">Select</option>
                <option value="central">Central</option>
                <option value="north">North</option>
                <option value="south">South</option>
                <option value="east">East</option>
                <option value="west">West</option>
              </select>
            </div>

            {/* Legal Name */}
            <div className="mb-6">
              <label className="block mb-2 text-sm font-medium text-gray-800">
                Legal Name of the Business (As mentioned in PAN) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="legalName"
                value={formData.legalName}
                onChange={handleInputChange}
                placeholder="Enter Legal Name of the Business"
                className="w-full p-2 border border-gray-300 rounded-md text-gray-800"
                required
              />
            </div>

            {/* PAN */}
            <div className="mb-6">
              <label className="block mb-2 text-sm font-medium text-gray-800">
                Permanent Account Number (PAN) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="panNumber"
                value={formData.panNumber}
                onChange={handleInputChange}
                placeholder="Enter Permanent Account Number (PAN)"
                className="w-full p-2 border border-gray-300 rounded-md text-gray-800"
                required
              />
            </div>

            {/* Email Address */}
            <div className="mb-2">
              <label className="block mb-2 text-sm font-medium text-gray-800">
                Email Address <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="Enter Email Address"
                className="w-full p-2 border border-gray-300 rounded-md text-gray-800"
                required
              />
            </div>
            <p className="text-xs text-gray-600 mb-6">OTP will be sent to this Email Address</p>

            {/* Mobile Number */}
            <div className="mb-2">
              <label className="block mb-2 text-sm font-medium text-gray-800">
                Mobile Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                name="mobile"
                value={formData.mobile}
                onChange={handleInputChange}
                placeholder="Enter Mobile Number"
                className="w-full p-2 border border-gray-300 rounded-md text-gray-800"
                required
              />
            </div>
            <p className="text-xs text-gray-600 mb-6">Separate OTP will be sent to this mobile number</p>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-blue-900 text-white py-3 rounded-md font-medium hover:bg-blue-800"
            >
              LOGIN
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}