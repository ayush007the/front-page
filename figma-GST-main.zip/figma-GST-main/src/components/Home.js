import React, { useState } from 'react';
import { ChevronRight, Phone, Mail, MessageSquare, Share2 } from 'lucide-react';
import TopNavBar from '../Layout/TopNavBar'; // Importing the TopNavBar component
import Header from '../Layout/Header';
import FullLengthImage from '../Layout/FullLengthImage';
import GSTNotificationBanner from '../Layout/GSTNotificationBanner';
import DashboardContent from './DashboardContent';
import Register from './Register';  // Make sure to import these components
// import Login from './Login';        // Make sure to import these components
import '../App.css';
import Navigation from '../Layout/Navigation';
import Footer from '../Layout/Footer'; // Importing the Footer component

export default function GSTWebsite() {
  const [currentView, setCurrentView] = useState('dashboard');
  
  const handleRegisterClick = () => {
    setCurrentView('register');
  };
  
  const handleLoginClick = () => {
    setCurrentView('login');
  };

  const renderContent = () => {
    switch (currentView) {
      case 'register':
        return <Register />;
      default:
        return <DashboardContent />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-blue-950 text-white">
      <TopNavBar />
      <Header 
        onRegisterClick={handleRegisterClick}
        onLoginClick={handleLoginClick}
      />
      {/* <Navigation /> */}
      <FullLengthImage src="https://www.gst.gov.in/images/gst-banner.jpg" alt="GST Banner" />
      <GSTNotificationBanner />
      
      {/* Main Content */}
      {renderContent()}

      <Footer />
    </div>
  );
}