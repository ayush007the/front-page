// GSTNotificationBanner.js
import React from "react";

function GSTNotificationBanner() {
  // Sample notifications - replace with your actual notifications
  const notifications = [
    "Important GST filing deadline approaching on May 15, 2025",
    "New GST compliance guidelines have been released",
    "Reminder: Submit your quarterly GST returns before the end of the month",
    "GST Council meeting scheduled for next week"
  ];
  
  const notificationText = notifications.join(" • ");

  return (
    <div className="flex h-8 sm:h-9 w-full items-center bg-[#FCF1CA] px-2 sm:px-4 md:px-7 py-1.5 relative">
      {/* Bell Icon Container - Fixed Position */}
      <div className="absolute left-2 sm:left-4 md:left-7 z-20 flex items-center">
        <div
          dangerouslySetInnerHTML={{
            __html:
              '<svg width="18" height="18" sm:width="22" sm:height="22" viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg" class="notification-icon"> <path d="M19.3976 15.768C19.3614 16.1275 19.2319 16.4713 19.0218 16.7653C18.8305 17.0487 18.5724 17.2805 18.2702 17.4404C17.968 17.6003 17.6311 17.6833 17.2893 17.682H14.5943C14.5466 17.9288 14.4761 18.1706 14.3834 18.4043C14.1989 18.8527 13.9272 19.26 13.5842 19.6027C13.2412 19.9454 12.8336 20.2167 12.3851 20.4008C11.9313 20.5842 11.4446 20.674 10.9551 20.6667H10.8818C10.4289 20.6625 9.98094 20.5722 9.56175 20.4008C9.10633 20.224 8.69383 19.9521 8.35175 19.6033C8.00634 19.2627 7.73486 18.8545 7.55425 18.4043C7.46156 18.1703 7.39098 17.9282 7.34342 17.6811H4.75842C4.42081 17.7081 4.08176 17.6511 3.77148 17.5154C3.4612 17.3796 3.18933 17.1691 2.98009 16.9028C2.78213 16.5814 2.65806 16.22 2.61684 15.8448C2.57563 15.4695 2.61829 15.0898 2.74175 14.7331C2.94108 14.2039 3.21253 13.7048 3.54842 13.2499C3.93453 12.7835 4.19347 12.2252 4.30009 11.6292C4.30009 8.98374 4.30008 8.08632 5.74842 6.36482C6.22591 5.79437 6.8197 5.33246 7.49008 5.00999L8.20509 4.66165C8.24008 4.63953 8.27107 4.61163 8.29675 4.57915C8.32443 4.54445 8.3433 4.50357 8.35175 4.45999C8.45585 4.01298 8.67017 3.59913 8.97519 3.25617C9.2802 2.91321 9.6662 2.65205 10.098 2.49649C10.5299 2.34054 10.9941 2.29525 11.448 2.36474C11.9019 2.43423 12.3312 2.61629 12.6968 2.89432C13.1981 3.29369 13.5264 3.8708 13.6134 4.50582V4.59749C13.6401 4.63491 13.6745 4.66617 13.7143 4.68915L14.3743 5.00999C15.0434 5.33082 15.6374 5.78915 16.1159 6.35565C17.5642 8.08632 17.5643 8.98374 17.5643 11.6292C17.6871 12.2617 17.9676 12.8539 18.3801 13.3507C18.7101 13.7917 18.9778 14.2757 19.1776 14.7881C19.3279 15.0924 19.404 15.4279 19.3976 15.768Z" fill="#FF0000"></path> </svg>',
          }}
          className="w-4 h-4 sm:w-5 sm:h-5"
        />
      </div>
      
      {/* Adding space for the bell icon */}
      <div className="w-6 sm:w-8"></div>
      
      {/* Marquee text with padding to avoid overlapping the bell */}
      <div className="w-full overflow-hidden pl-2 sm:pl-4">
        <div
          dangerouslySetInnerHTML={{
            __html: `
              <marquee behavior="scroll" direction="left" scrollamount="3" class="text-red-800 text-xs sm:text-sm font-medium">
                ${notificationText}
              </marquee>
            `
          }}
        />
      </div>
    </div>
  );
}

export default GSTNotificationBanner;