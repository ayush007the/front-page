
// TopNavBar.js
import React from 'react';

const TopNavBar = () => {
  return (
    <div className="top-nav-bar-color text-white py-1 px-2 sm:px-4 flex justify-end items-center text-xs">
      <div className="hidden sm:block cursor-pointer hover:underline mr-4">Skip to Main Content</div>
      <div className="flex space-x-1">
        <button className="focus:outline-none p-1 font-medium">A+</button>
        <span className="mx-1">|</span>
        <button className="focus:outline-none p-1 font-medium">A-</button>
      </div>
    </div>
  );
};

export default TopNavBar;