import React, { useState } from 'react';

const Navigation = () => {
  const [activeItem, setActiveItem] = useState('Home');
  
  const navItems = [
    { name: 'Home', hasDropdown: false },
    { name: 'Services', hasDropdown: true },
    { name: 'GST Law', hasDropdown: false },
    { name: 'Downloads', hasDropdown: true },
    { name: 'Search Taxpayer', hasDropdown: true },
    { name: 'Help and Taxpayer Facilities', hasDropdown: false },
    { name: 'e-Invoice', hasDropdown: false },
    { name: 'News and Updates', hasDropdown: false }
  ];
  
  const handleNavClick = (itemName) => {
    setActiveItem(itemName);
    // Additional navigation logic would go here
  };
  
  return (
    <nav className="w-full color-navigation text-white text-lg">
      <ul className="flex justify-center ">
        {navItems.map((item, index) => (
          <li 
            key={index}
            className={`px-4 py-3 cursor-pointer border border-gray-600 hover:bg-blue-700 transition-colors duration-200 ${
              activeItem === item.name ? 'bg-teal-500 border-teal-400' : ''
            }`}
            onClick={() => handleNavClick(item.name)}
          >
            <div className="flex items-center whitespace-nowrap">
              {item.name}
              {item.hasDropdown && <span className="ml-1">▾</span>}
            </div>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navigation;