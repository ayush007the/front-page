import React from "react";

export default function Footer() {
  return (
    <footer className="footer-color text-white text-left">
      {/* Main footer navigation */}
      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          {/* About GST Column */}
          <div>
            <h3 className="heading-footer font-medium mb-4">About GST</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  GST Council Structure
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  GST History
                </a>
              </li>
            </ul>
          </div>

          {/* Website Policies Column */}
          <div className="text-left"> 
            <h3 className="heading-footer font-medium mb-4">
              Website Policies
            </h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Website Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Terms and Conditions
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Hyperlink Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Disclaimer
                </a>
              </li>
            </ul>
          </div>

          {/* Related Sites Column */}
          <div className="text-left">
            <h3 className="heading-footer font-medium mb-4">Related Sites</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Central Board of Indirect Taxes and Customs
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  State Tax Websites
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  National Portal
                </a>
              </li>
            </ul>
          </div>

          {/* Help and Taxpayer Facilities Column */}
          <div className="text-left">
            <h3 className="heading-footer font-medium mb-4">
              Help and Taxpayer Facilities
            </h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  System Requirements
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  GST Knowledge Portal
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  GST Media
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Site Map
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Grievance Nodal Officers
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  Free Accounting and Billing Services
                </a>
              </li>
              <li>
                <a href="#" className="text-color-footer hover:underline">
                  GST Suvidha Providers
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Us Column */}
          <div className="text-left">
            <h3 className="heading-footer font-medium mb-4 text-left">
              Contact Us
            </h3>
            <div className="text-color-footer space-y-3 text-sm text-left">
              <p className="text-left">
                Help Desk Number:
                <br />
                1800-103-4786
              </p>
              <div className="text-color-footer pt-2 text-left">
                <p className="text-left">
                  Log/Track Your Issue:
                  <br />
                  Grievance Redressal Portal for GST
                </p>
              </div>
              <div className="flex space-x-4 pt-2 text-left">
                <a href="#" className="text-color-footer hover:text-cyan-300">
                  <span className="text-xl">ƒ</span>
                </a>
                <a href="#" className="text-color-footer hover:text-cyan-300">
                  <span className="text-lg">▶</span>
                </a>
                <a href="#" className="text-color-footer hover:text-cyan-300">
                  <span className="text-lg">✕</span>
                </a>
                <a href="#" className="text-color-footer hover:text-cyan-300">
                  <span className="text-lg">in</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright section */}
      <div className="border-t border-blue-800">
        <div className="container mx-auto px-6 py-3 flex flex-col md:flex-row justify-between text-sm">
          <div>© 2025-26 Goods and Services Tax Network</div>
          <div>Site Last Updated on 25-04-2025</div>
          <div>Designed & Developed by GSTN</div>
        </div>
      </div>

      {/* Browser compatibility notice */}
      <div className="bg-blue-950 py-2 px-4 text-xs text-center">
        Site best viewed at 1024 x 768 resolution in Microsoft Edge, Google
        Chrome 49+, Firefox 45+ and Safari 6+
      </div>
    </footer>
  );
}
