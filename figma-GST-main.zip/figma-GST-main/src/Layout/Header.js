// Header.js
import React, { useState } from 'react';
import asSvg from '../assets/as.svg';
import Navigation from './Navigation'; // Import the Navigation component

const Header = ({ onRegisterClick, onLoginClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="header-color text-white">
      <div className="py-2 sm:py-3 px-3 sm:px-6 md:px-12 lg:px-20">
        <div className="flex justify-between items-center">
          {/* Logo and Title */}
          <div className="flex items-center">
            <div className="mr-2 sm:mr-4">
              <img src={asSvg} alt="Government of India Emblem" width="32" height="40" className="sm:w-10 sm:h-12 md:w-12 md:h-16" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-semibold leading-tight">
                Goods and Services Tax
              </h1>
              <p className="text-xs sm:text-sm leading-tight hidden sm:block">
                Government of India, States and Union Territories
              </p>
            </div>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>

          {/* Desktop login/register buttons */}
          <div className="hidden md:flex space-x-2">
            <button
              className="bg-white text-blue-900 px-3 py-1 rounded text-sm font-medium"
              onClick={onRegisterClick}
            >
              REGISTER
            </button>
            <button
              className="bg-white text-blue-900 px-3 py-1 rounded text-sm font-medium"
              onClick={onLoginClick}
            >
              LOGIN
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-2 flex flex-col space-y-2">
            <button
              className="bg-white text-blue-900 px-3 py-1 rounded text-sm font-medium w-full"
              onClick={onRegisterClick}
            >
              REGISTER
            </button>
            <button
              className="bg-white text-blue-900 px-3 py-1 rounded text-sm font-medium w-full"
              onClick={onLoginClick}
            >
              LOGIN
            </button>
            
            {/* Mobile Navigation */}
            <MobileNavigation />
          </div>
        )}
      </div>

      {/* Desktop Navigation - hidden on mobile */}
      <div className="hidden md:block">
        <Navigation />
      </div>
    </header>
  );
};

// Mobile Navigation Component
const MobileNavigation = () => {
  const [activeItem, setActiveItem] = useState('Home');
  const [expandedItem, setExpandedItem] = useState(null);
 
  const navItems = [
    { name: 'Home', hasDropdown: false },
    { name: 'Services', hasDropdown: true, dropdownItems: ['Service 1', 'Service 2', 'Service 3'] },
    { name: 'GST Law', hasDropdown: false },
    { name: 'Downloads', hasDropdown: true, dropdownItems: ['Download 1', 'Download 2'] },
    { name: 'Search Taxpayer', hasDropdown: true, dropdownItems: ['Search by GSTIN', 'Search by Name'] },
    { name: 'Help and Taxpayer Facilities', hasDropdown: false },
    { name: 'e-Invoice', hasDropdown: false },
    { name: 'News and Updates', hasDropdown: false }
  ];
 
  const handleNavClick = (itemName) => {
    setActiveItem(itemName);
    // Collapse if clicking on same item, expand if clicking on different item
    setExpandedItem(expandedItem === itemName ? null : itemName);
  };
 
  return (
    <nav className="w-full bg-blue-900 text-white">
      <ul className="flex flex-col">
        {navItems.map((item, index) => (
          <li key={index} className="border-t border-blue-700">
            <div
              className={`px-4 py-3 cursor-pointer hover:bg-blue-700 transition-colors duration-200 ${
                activeItem === item.name ? 'bg-blue-700' : ''
              }`}
              onClick={() => handleNavClick(item.name)}
            >
              <div className="flex items-center justify-between">
                <span>{item.name}</span>
                {item.hasDropdown && (
                  <span className="ml-1">{expandedItem === item.name ? '▴' : '▾'}</span>
                )}
              </div>
            </div>
            
            {/* Dropdown items */}
            {item.hasDropdown && expandedItem === item.name && (
              <ul className="bg-blue-800">
                {item.dropdownItems.map((dropdownItem, idx) => (
                  <li
                    key={idx}
                    className="px-8 py-2 cursor-pointer hover:bg-blue-600 border-t border-blue-700"
                  >
                    {dropdownItem}
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Header;