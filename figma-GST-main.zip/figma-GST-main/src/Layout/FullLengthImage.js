// FullLengthImage.js
import React from 'react';
import image from '../img/image.png'
const FullLengthImage = ({ src, alt }) => {
  return (
    <div className="w-full">
      <img 
        src={image} 
        alt={alt} 
        className="w-full h-fit object-cover" 
      />
    </div>
  );
};

export default FullLengthImage;